OK_FORMAT = True

test = {   'name': 'q6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> dow(8,30,2021) == "Monday"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> dow(11,22,1963) == "Friday"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> dow(11,25,2021) == "Thursday"\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> def solved(m,d,y):\n'
                                               '...     days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]\n'
                                               '...     y-=int(m<3)\n'
                                               '...     m = m - 2 if m > 3 else m+10\n'
                                               '...     W = (d + int(2.6*m - 0.2) - 2*(y//100) + y%100 + (y%100)//4 + y//400) % 7\n'
                                               '...     return days[W]\n'
                                               '>>> \n'
                                               '>>> assert dow(10,31,2016) == solved(10,31,2016)\n',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': '>>> def solved(m,d,y):\n'
                                               '...     days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]\n'
                                               '...     y-=int(m<3)\n'
                                               '...     m = m - 2 if m > 3 else m+10\n'
                                               '...     W = (d + int(2.6*m - 0.2) - 2*(y//100) + y%100 + (y%100)//4 + y//400) % 7\n'
                                               '...     return days[W]\n'
                                               '>>> \n'
                                               '>>> assert dow(8,27,1964) == solved(8,27,1964)\n',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': '>>> def solved(m,d,y):\n'
                                               '...     days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]\n'
                                               '...     y-=int(m<3)\n'
                                               '...     m = m - 2 if m > 3 else m+10\n'
                                               '...     W = (d + int(2.6*m - 0.2) - 2*(y//100) + y%100 + (y%100)//4 + y//400) % 7\n'
                                               '...     return days[W]\n'
                                               '>>> \n'
                                               '>>> assert dow(2,29,2000) == solved(2,29,2000)\n',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': '>>> def solved(m,d,y):\n'
                                               '...     days=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]\n'
                                               '...     y-=int(m<3)\n'
                                               '...     m = m - 2 if m > 3 else m+10\n'
                                               '...     W = (d + int(2.6*m - 0.2) - 2*(y//100) + y%100 + (y%100)//4 + y//400) % 7\n'
                                               '...     return days[W]\n'
                                               '>>> \n'
                                               '>>> assert dow(12,31,1999) == solved(12,31,1999)\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
