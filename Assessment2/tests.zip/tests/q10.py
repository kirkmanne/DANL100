OK_FORMAT = True

test = {   'name': 'q10',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> pv(1000,4,7) == 759.92\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> pv(50000,0.5,120) == 27481.64\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert pv(100000,21,36) == 104.65\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert pv(1000,6,24) == 246.98\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
