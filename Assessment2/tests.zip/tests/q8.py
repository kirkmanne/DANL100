OK_FORMAT = True

test = {   'name': 'q8',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> reverse(5) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> reverse(54321) == 12345\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert reverse(12345678) == 87654321\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert reverse(369) == 963\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
