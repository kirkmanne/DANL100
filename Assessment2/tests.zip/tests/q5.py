OK_FORMAT = True

test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> rotate([1,2,3,4,5,6,7,8,9],1) == [2, 3, 4, 5, 6, 7, 8, 9, 1]\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> rotate([1,2,3,4,5,6,7,8,9],-3) == [7, 8, 9, 1, 2, 3, 4, 5, 6]\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert rotate([1,2,3,4,5,6,7,8,9],-9) == [1,2,3,4,5,6,7,8,9]\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert rotate([1,2,3,4,5,6,7,8,9],9) == [1,2,3,4,5,6,7,8,9]\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
