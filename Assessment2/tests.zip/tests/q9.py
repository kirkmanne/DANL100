OK_FORMAT = True

test = {   'name': 'q9',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> roman(1234) == "MCCXXXIV"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> roman(3888) == 'MMMDCCCLXXXVIII'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert roman(1999) == 'MCMXCIX'\n", 'hidden': True, 'locked': False},
                                   {'code': '>>> assert roman(555) == "DLV"\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
