OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> addup([]) == 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> addup([5,4,3,2,1]) == 15\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> orig_sum = sum\n>>> sum = None\n>>> assert addup([3,2,1]) == 6\n>>> sum=orig_sum\n', 'hidden': True, 'locked': False},
                                   {   'code': '>>> orig_sum = sum\n>>> sum = None\n>>> assert addup([10,9,8,7,6,5,4,3,2,1]) == orig_sum([10,9,8,7,6,5,4,3,2,1])\n>>> sum=orig_sum\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
