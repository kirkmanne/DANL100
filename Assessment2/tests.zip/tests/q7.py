OK_FORMAT = True

test = {   'name': 'q7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> count(0,[1,2,3,5,6,7,8,9]) == 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> count(1,[1,2,3,1,2,3,1,2,3]) == 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert count(1,[1]*10) == 10\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert count(5,[1,2,3,4,5,1,2,3,4,5]) == 2\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
