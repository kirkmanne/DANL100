OK_FORMAT = True

test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> chop("") == ""\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> chop("abc") == "ac"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> chop("abcd") == "ad"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert chop("123456789") == "12346789"\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert chop("12345678") == "123678"\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
