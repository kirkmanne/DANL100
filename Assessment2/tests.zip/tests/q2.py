OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> largest([6,5,4,3,2,1]) == 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> largest([5,4,3,2,1]) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> orig_max = max\n'
                                               '>>> orig_sorted = sorted\n'
                                               '>>> min = None\n'
                                               '>>> sorted = None\n'
                                               '>>> assert largest([3,2,1]) == 3\n'
                                               '>>> max=orig_max\n'
                                               '>>> sorted=orig_sorted\n',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': '>>> orig_max = max\n'
                                               '>>> orig_sorted = sorted\n'
                                               '>>> max=None\n'
                                               '>>> sorted=None\n'
                                               '>>> assert largest([10,9,8,7,6,5]) == 10\n'
                                               '>>> max=orig_max\n'
                                               '>>> sorted=orig_sorted\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
