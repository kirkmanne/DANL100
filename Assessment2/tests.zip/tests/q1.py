OK_FORMAT = True

test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> smallest([]) == None\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> smallest([5,4,3,2,1]) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> orig_min = min\n'
                                               '>>> orig_sorted = sorted\n'
                                               '>>> min = None\n'
                                               '>>> sorted = None\n'
                                               '>>> assert smallest([3,2,1]) == 1\n'
                                               '>>> min=orig_min\n'
                                               '>>> sorted=orig_sorted\n',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': '>>> orig_min = min\n'
                                               '>>> orig_sorted = sorted\n'
                                               '>>> min = None\n'
                                               '>>> sorted = None\n'
                                               '>>> assert smallest([10,9,8,7,6,5]) == 5\n'
                                               '>>> min=orig_min\n'
                                               '>>> sorted=orig_sorted\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
