OK_FORMAT = True

test = {   'name': 'q01',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> largest(12,1) == 12\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> largest(4,29) == 29\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> largest(10,10) == 10\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
