OK_FORMAT = True

test = {   'name': 'q04',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> median([1,2,3]) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> median([1,2,3,4])==5/2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> median([1])==1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> median([5,4,3,2,1])==3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
