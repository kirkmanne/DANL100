OK_FORMAT = True

test = {   'name': 'q05',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> breakeven(10000,25,13) == 20833\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> breakeven(15000,3,1.5) == 30000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> breakeven(5000,2,10) == -1250\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
