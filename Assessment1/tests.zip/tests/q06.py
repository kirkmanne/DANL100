OK_FORMAT = True

test = {   'name': 'q06',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> palindrome("saippuakivikauppias")==True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> palindrome("tattarrattat")==True\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> palindrome("Nope")==False\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> palindrome("poppycock")==False\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
