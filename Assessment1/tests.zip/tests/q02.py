OK_FORMAT = True

test = {   'name': 'q02',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> smallest(1,2,3) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> smallest(30,20,10) == 10\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> smallest(5,0,20) == 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
